var fetch = global.nodemodule["node-fetch"];

function onLoad(data) {

var onLoadText = "Đang tải kit thiên văn học by DauPhuAB";
onLoadText += "\n\n";
onLoadText += "================================================================================\n";
onLoadText += "=                     ----------------------------------                       =\n";
onLoadText += "=                              Admin Bot Chat                                  =\n";
onLoadText += "=                     ==================================                       =\n";
onLoadText += "=                           *Facebook : Đậu Phụ Nè                             =\n";
onLoadText += "=                          *Plugin run by DauPhuAB*                            =\n";
onLoadText += "=                       Loader admin bot chat V1.0                             =\n";
onLoadText += "=                            Plugin For C3C Bot                                =\n";
onLoadText += "=                       Thank for the used and download                        =\n";
onLoadText += "=                     ==================================                       =\n";
onLoadText += "================================================================================\n";
onLoadText += "#############################################\n";
onLoadText += "Phiên bản hiện tại đang là mới nhất\n";
onLoadText += "#############################################\n";
onLoadText += "Đã tải xong plugins kit thiên văn học ^^\n";
onLoadText += "Đang sẵn sàng cho lần chạy này ..... \n"

data.log(onLoadText);
data.log(data);

}

var adminbotchat = function adminbotchat(type, data) {
	(async function () {
		var returntext = `Chủ bot : Thìn(northerwind)\nLink Facebook :https://www.facebook.com/huuthin.nguyen.9678/\nChú ý : Mỗi nhóm chỉ được phép add một con bot và lưu ý rằng không được phép kick ra nhét vào tránh bị ban\nCảm ơn bạn đã sử dụng sản phẩm ^3^`;
		return {
			handler: "internal",
			data: returntext
		}
	})().then(function (returndata) {
		data.return(returndata);
	});
} 

module.exports = {
	adminbotchat: adminbotchat,
	onLoad
};